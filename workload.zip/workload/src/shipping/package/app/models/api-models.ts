// GENERATED FILE - DO NOT EDIT

export class Package
{
  id:string
  size:string
  weight:number
  tag:string
}

export class PackageUtilization
{
  totalWeight:number
}

export class Error
{
  code:number
  message:string
}

