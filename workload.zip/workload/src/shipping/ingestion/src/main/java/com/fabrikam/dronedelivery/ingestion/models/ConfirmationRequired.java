package com.fabrikam.dronedelivery.ingestion.models;

public enum ConfirmationRequired {
	FingerPrint, 
	Picture, 
	Voice,
	None
}
