#!/bin/bash
dotnet Fabrikam.DroneDelivery.DeliveryService.dll
