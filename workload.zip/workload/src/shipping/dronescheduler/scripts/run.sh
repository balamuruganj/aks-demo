#!/bin/bash
dotnet Fabrikam.DroneDelivery.DroneSchedulerService.dll
